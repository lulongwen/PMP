# HTML

```html
    <div></div>
    <img src="" alt="">
    <p></p>
    <h1></h1>
    <h2></h2>
    <h3></h3>
    <hgroup></hgroup>
    
    <table width="200" border="1">
      <tbody>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </tbody>
    </table>
    
<table width="200" border="1">
  <tbody>
    <tr>
      <th scope="col">&nbsp;</th>
      <th scope="col">&nbsp;</th>
      <th scope="col">&nbsp;</th>
    </tr>
    <tr>
      <th scope="row">&nbsp;</th>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <th scope="row">&nbsp;</th>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </tbody>
</table>
	
	<table width="200" border="1">
  <tbody>
    <tr>
      <th scope="col">&nbsp;</th>
      <th scope="col">&nbsp;</th>
      <th scope="col">&nbsp;</th>
    </tr>
    <tr>
      <th scope="row">&nbsp;</th>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <th scope="row">&nbsp;</th>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </tbody>
</table>
	<ul></ul>
<figure>这是布局标签的内容<figcaption>这是布局图标签的题注</figcaption></figure>
	<ol></ol>
<table width="200" border="1" cellspacing="2" cellpadding="2" summary="123">
  <caption>
    12123
  </caption>
  <tbody>
    <tr>
      <th scope="col">&nbsp;</th>
      <th scope="col">&nbsp;</th>
      <th scope="col">&nbsp;</th>
    </tr>
    <tr>
      <th scope="row">&nbsp;</th>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <th scope="row">&nbsp;</th>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </tbody>
</table>
<a href="#">123</a>
<header>
  <nav>此处为新 header 标签的内容</nav>
</header>
<br>
&nbsp;<hr>
<iframe>function areaOfCircle(radius) { return Math.PI * Math.pow(radius, 2); }

<div>此处显示新 Div 标签的内容<p><img src="shop/4.jpg" width="1294" height="776" alt=""/></p></div>
</iframe>
	
<main>此处为新 main 标签的内容</main>
	
<aside>此处为新 aside 标签的内容</aside>
<article>
  <section>此处为新 article 标签的内容</section>
</article>
<footer>此处为新 footer 标签的内容</footer>
	<meta http-equiv="" content="">
	<meta name="keywords" content="12">
<meta name="description" content="123">
<meta name="viewport" content="width=device-width, initial-scale=1">
<a href="mailto:123@qq.com">123</a>
	
<video controls></video>
<canvas></canvas>
<audio controls></audio>
	<iframe></iframe>
	<hr>
&nbsp;
	&nbsp;<br>
	<!-- TemplateBeginIf cond="OptionalRegion1" -->
	/* For non-retina based devices that have a smaller screen */
@media only screen and (min-width: 320px) {

}

/* Retina enabled devices with smaller screen */
@media  only screen and (-webkit-min-device-pixel-ratio: 2) and (min-width: 320px), 
only screen and ( -o-min-device-pixel-ratio: 2/1) and (min-width: 320px),  
only screen and ( min-device-pixel-ratio: 2) and (min-width: 320px),  
only screen and ( min-resolution: 192dpi) and (min-width: 320px),  
only screen and ( min-resolution: 2dppx) and (min-width: 320px) {

}

/*Non- retina based devices with medium screen size */
@media only screen and (min-width: 768px) {

}

/* Retina devices with medium screen size */
@media only screen and (-webkit-min-device-pixel-ratio: 2) and (min-width: 768px),  
only screen and ( -o-min-device-pixel-ratio: 2/1) and (min-width: 768px),  
only screen and ( min-device-pixel-ratio: 2) and (min-width: 768px),  
only screen and ( min-resolution: 192dpi) and (min-width: 768px),  
only screen and ( min-resolution: 2dppx) and (min-width: 768px) {

}

/* Non-retina devices with large screen sizes */
@media only screen and (min-width: 1200px) {

}

/* Retina devices with large screen sizes */
@media  only screen and (-webkit-min-device-pixel-ratio: 2) and (min-width: 1200px),  
only screen and ( -o-min-device-pixel-ratio: 2/1) and (min-width: 1200px),  
only screen and ( min-device-pixel-ratio: 2) and (min-width: 1200px),  
only screen and ( min-resolution: 192dpi) and (min-width: 1200px),  
only screen and ( min-resolution: 2dppx) and (min-width: 1200px) {

}<nav class="navbar navbar-expand-lg navbar-light bg-light">OptionalRegion1</nav>
```
